Installation
============

- From PyPI::

      pip install sshuttle

- Clone::

      git clone https://github.com/sshuttle/sshuttle.git
      ./setup.py install
