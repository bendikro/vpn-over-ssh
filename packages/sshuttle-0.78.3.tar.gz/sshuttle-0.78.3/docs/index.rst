sshuttle: where transparent proxy meets VPN meets ssh
=====================================================

:Date: |today|
:Version: |version|

Contents:

.. toctree::
   :maxdepth: 2

   overview
   requirements
   installation
   usage
   platform
   Man Page <manpage>
   how-it-works
   support
   trivia
   changes


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

